<?php
$string['pluginname'] = 'Simple tracker4 block';
$string['tracker4'] = 'Simple tracker4';
$string['overview']='Access tracker4';
$string['tracker4:addinstance'] = 'Add a new simple tracker4 block';
$string['tracker4:myaddinstance'] = 'Add a new simple tracker4 block to the My Moodle page';